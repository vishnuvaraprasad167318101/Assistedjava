package ap1;

public class ProtectAS {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}

