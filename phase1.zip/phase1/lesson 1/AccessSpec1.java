package ap1;

public class AccessSpec1 {
	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access Specifier");
		DefaultAS obj = new DefaultAS(); 		  
        obj.display(); 

	}

}
