package ap1;

public class PublicAS {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 

}
