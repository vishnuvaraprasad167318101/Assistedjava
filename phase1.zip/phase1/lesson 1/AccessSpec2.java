package ap1;

public class AccessSpec2 {
public static void main(String[] args) {
		
		System.out.println("Private Access Specifier");
		PrivateAS  obj = new PrivateAS (); 
        
	}
}

