package ap1;


	public class AccessSpec3  extends ProtectAS {

		public static void main(String[] args) {
			ProtectAS obj = new ProtectAS();   
		       obj.display();  
		}

	}


