package ap1;

public class DefaultAS {
	
	  void display() 
	     { 
	         System.out.println("You are using defalut access specifier"); 
	     } 
	} 

