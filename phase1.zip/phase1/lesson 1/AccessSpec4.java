package ap1;

public class AccessSpec4 {

	public static void main(String[] args) {
		
		PublicAS obj = new PublicAS(); 
        obj.display();  
		
	}
}



